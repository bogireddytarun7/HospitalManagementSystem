package com.Console;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateProjFileServlet
 */
public class CreateProjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CreateProjectServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		ServletContext context = request.getSession().getServletContext();
		String rootFolder = context.getInitParameter("projectroot");
		String mode = request.getParameter("mode");
		String filename = request.getParameter("filename");
		File file = null; 
		try{
			File f = new File(rootFolder);
			if(!f.exists()){
				out.println("No Projects available. Please create a Project");
				return;
			}
			if("filename".equals(mode)){
				String projectname = request.getParameter("project");
				file = new File(rootFolder+"/"+projectname, filename);
				file.createNewFile();
				out.println("File Created Successfully");
			}else if("project".equals(mode)){
				File projs = new File( rootFolder );
				if(!projs.exists())
					projs.mkdir(); 
				file = new File(projs, filename);
				file.mkdir();
				out.println("Project Created Successfully");
			}else{
				File projs = new File( rootFolder );
				File[] files = projs.listFiles();
				if(files.length == 0){
					out.println("No Projects available. Please create a Project");
				}else{
					for (File file2 : files) {
						out.println("<div class='.loadProject'>"+file2.getName()+"</div>");
					}
				}
			}
		}catch(Exception e){
			out.println("Error while creating "+mode+" - "+e.getMessage());	
		}
	}

}
