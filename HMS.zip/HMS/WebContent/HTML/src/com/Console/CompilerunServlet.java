package com.Console;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;

/**
 * Servlet implementation class CompileServlet
 */
public class CompilerunServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CompilerunServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		ServletContext context = request.getSession().getServletContext();
		String rootFolder = context.getInitParameter("projectroot");
		
		String projectname = request.getParameter("project");
		String mode = request.getParameter("mode");
		PrintWriter out = response.getWriter();
		if (projectname == null) {
			out.println("Project Not Found");
			return;
		} else {
			projectname = projectname.trim();
		}
		if ("".equals(projectname)) {
			out.println("Project Name is Empty");
		} else {
			try {
				File dir = new File(rootFolder, projectname);
				if (!dir.exists()) {
					out.println("Project Not Found on Server");
					return;
				}
				File outDir = new File(dir, "output");
				String filename = request.getParameter("filename").trim();
				if ("run".equals(mode)) { 
					String outputppath = outDir.toString();
					filename = filename.replace(".java", "");
					Collection<File> ft = FileUtils.listFiles(outDir, new String[]{"class"}, true); 
					if(ft.isEmpty()) {
						out.println(filename +" Class Not found. Please compile the java file before running");
					}
					else{
						Map<String, String> classMap = getClassMap(ft,outDir.toString()); 
						runProcess("java -cp .;"+outputppath+" "+classMap.get(filename) , out, filename);
					}
						
				} else {
					FileUtils.deleteDirectory(outDir);
					outDir.mkdir();
					File file = new File(dir, filename);
					compileProcess("javac " + file + " -d " + outDir, out,
							filename);
				}
			} catch (Exception e) {
				System.out.println("Compile Servlet ::: Exception occured  "
						+ e.getMessage());
				e.printStackTrace(); 
			}

		}
	}
	
	private Map<String, String> getClassMap(Collection<File> ft,String outDir) { 
		Iterator<File> file = ft.iterator();
		Map<String, String> map = new HashMap<String, String>();
		while(file.hasNext()){
			File f = file.next();
			String value = f.getPath().replace(".class", "").replace(outDir, "").replaceAll("\\\\"," ").trim();
			//System.out.println(f.toString()+" -- "+f.getName());
			map.put(f.getName().replace(".class", ""), value.replace(" ", ".") );
		}
		return map;
	}

	private boolean printLines(String name, InputStream ins, PrintWriter out)
			throws Exception {
		String line = null;
		boolean flag = false;
		BufferedReader in = new BufferedReader(new InputStreamReader(ins));
		while ((line = in.readLine()) != null) {
			out.println(name + " " + line);
			flag = true;
		}
		return flag;
	}

	private int runProcess(String command, PrintWriter out, String filename)
			throws Exception {
		Process pro = Runtime.getRuntime().exec(command);
		printLines(filename + " stdout:", pro.getInputStream(), out);
		printLines(filename + " stderr:", pro.getErrorStream(), out);
		pro.waitFor();
		return pro.exitValue();
	}

	private int compileProcess(String command, PrintWriter out, String filename)
			throws Exception {
		Process pro = Runtime.getRuntime().exec(command);
		printLines(filename + " stdout:", pro.getInputStream(), out);
		boolean stderr = printLines(filename + " stderr:",
				pro.getErrorStream(), out);
		if (!stderr) {
			out.println(filename + ":: Compiled Successfully");
		}
		pro.waitFor();
		return pro.exitValue();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
