package com.hms.util;

public class NumberCheck {
	
	public boolean isNumeric(String string)
	{
		try
	    {
	      double number = Double.parseDouble(string);
	    }
	    catch(NumberFormatException nfe)
	    {
	      return false;
	    }
	    return true;
	}

}
