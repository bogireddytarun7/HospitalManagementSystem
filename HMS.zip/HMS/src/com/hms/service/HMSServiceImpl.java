package com.hms.service;

import java.util.List;

import com.hms.dao.HMSDaoImpl;
import com.hms.dao.IHMSDao;
import com.hms.domain.Bed;
import com.hms.domain.BillGroup;
import com.hms.domain.Department;
import com.hms.domain.Designation;
import com.hms.domain.IPDPatient;
import com.hms.domain.LoginUser;
import com.hms.domain.OPDPatient;
import com.hms.domain.Patient;
import com.hms.domain.Room;
import com.hms.domain.RoomCategory;
import com.hms.domain.UserCredentials;
import com.hms.domain.UserRole;

public class HMSServiceImpl implements IHMSService{

	private IHMSDao dao;
	public boolean verify(String username,String password)
	{	
		dao=new HMSDaoImpl();
		return dao.verify(username, password);
	}
	
	public LoginUser getProfile(String username) {
		dao=new HMSDaoImpl();
		return dao.getProfile(username);
	}
	
	public boolean updateProfile(LoginUser user) {
		dao=new HMSDaoImpl();
		
		return dao.updateProfile(user);
	}
	
	public boolean changePassword(UserCredentials credentials) {
		dao=new HMSDaoImpl();
		return dao.changePassword(credentials);
	}

	public List<Department> getDepartments() {
		dao=new HMSDaoImpl();
		return dao.getDepartments();
	}

	public boolean addDepartment(String departmentName) {
		dao=new HMSDaoImpl();
		return dao.addDepartment(departmentName);
	}

	public Department getDepartment(int department_id) {
		dao=new HMSDaoImpl();
		return dao.getDepartment(department_id);
	}

	public boolean modifyDepartment(Department department) {
		
		dao=new HMSDaoImpl();
		return dao.modifyDepartment(department);
	}

	public boolean deleteDepartment(Department department) {
		dao=new HMSDaoImpl();
		return dao.deleteDepartment(department);
	}

	public List<Designation> getDesignations() {
		dao=new HMSDaoImpl();
		return dao.getDesignations();
	}

	public boolean addDesignation(Designation designation) {
		dao=new HMSDaoImpl();
		return dao.addDesignation(designation);
	}

	public Designation getDesignation(Designation designation) {
		dao=new HMSDaoImpl();
		return dao.getDesignation(designation);
	}

	public boolean modifyDesignation(Designation designation) {
		dao=new HMSDaoImpl();
		return dao.modifyDesignation(designation);
	}

	public boolean deleteDesignation(Designation designation) {
		dao=new HMSDaoImpl();
		return dao.deleteDesignation(designation);
	}

	public List<BillGroup> getBillGroups() {
		dao=new HMSDaoImpl();
		return dao.getBillGroups();
	}

	public boolean addBillGroup(BillGroup billgroup) {
		dao=new HMSDaoImpl();
		return dao.addBillGroup(billgroup);
	}

	public BillGroup getBillGroup(BillGroup billgroup) {
		dao=new HMSDaoImpl();
		return dao.getBillGroup(billgroup);
	}

	public boolean modifyBillGroup(BillGroup billgroup) {
		dao=new HMSDaoImpl();
		return dao.modifyBillGroup(billgroup);
	}

	public boolean deleteBillGroup(BillGroup billgroup) {
		dao=new HMSDaoImpl();
		return dao.deleteBillGroup(billgroup);
	}

	public List<UserRole> getUserRoles() {
		dao=new HMSDaoImpl();
		return dao.getUserRoles();
	}

	public boolean addNewUser(LoginUser user) {
		dao=new HMSDaoImpl();
		return dao.addNewUser(user);
	}

	public List<LoginUser> getUsers() {
		dao=new HMSDaoImpl();
		return dao.getUsers();
	}

	public LoginUser getProfile(int userid) {
		dao=new HMSDaoImpl();
		return dao.getProfile(userid);
	}

	public boolean modifyUser(LoginUser user) {
		dao=new HMSDaoImpl();
		return dao.modifyUser(user);
	}

	public boolean deleteUser(LoginUser user) {
		dao=new HMSDaoImpl();
		return dao.deleteUser(user);
	}

	public boolean checkUser(String username,int userid) {
		dao=new HMSDaoImpl();
		return dao.checkUser(username,userid);
	}

	public boolean createCredentials(LoginUser user) {
		dao=new HMSDaoImpl();
		return dao.createCredentials(user);
	}

	public List<RoomCategory> getRoomCategories() {
		dao=new HMSDaoImpl();
		return dao.getRoomCategories();
	}

	public boolean addRoomCategory(RoomCategory category) {
		dao=new HMSDaoImpl();
		return dao.addRoomCategory(category);
	}

	public RoomCategory getRoomCategory(RoomCategory category) {
		dao=new HMSDaoImpl();
		return dao.getRoomCategory(category);
	}

	public boolean modifyRoomCategory(RoomCategory category) {
		dao=new HMSDaoImpl();
		return dao.modifyRoomCategory(category);
	}

	public boolean deleteRoomCategory(RoomCategory category) {
		dao=new HMSDaoImpl();
		return dao.deleteRoomCategory(category);
	}

	public List<Room> getRooms() {
		dao=new HMSDaoImpl();
		return dao.getRooms();
	}

	public List<Bed> getBeds() {
		dao=new HMSDaoImpl();
		return dao.getBeds();
	}

	public int getNewPatientID() {
		dao=new HMSDaoImpl();
		return dao.getNewPatientID();
	}

	public boolean addPatient(Patient patient) {
		dao=new HMSDaoImpl();
		return dao.addPatient(patient);
	}

	public List<Patient> getPatients() {
		dao=new HMSDaoImpl();
		return dao.getPatients();
	}

	public Patient getPatientProfile(Integer patientID) {
		dao=new HMSDaoImpl();
		return dao.getPatientProfile(patientID);
	}

	public boolean modifyPatientProfile(Patient patient) {
		dao=new HMSDaoImpl();
		return dao.modifyPatientProfile(patient);
	}

	public List<LoginUser> getDoctors() {
		dao=new HMSDaoImpl();
		return dao.getDoctors();
	}

	public int getNewOPDPatientID() {
		dao=new HMSDaoImpl();
		return dao.getNewOPDPatientID();
	}

	public boolean addOPDPatient(OPDPatient patient) {
		dao=new HMSDaoImpl();
		return dao.addOPDPatient(patient);
	}

	public List<OPDPatient> getOPDPatients() {
		dao=new HMSDaoImpl();
		return dao.getOPDPatients();
	}

	public List<OPDPatient> getOPDPatients(String username) {
		dao=new HMSDaoImpl();
		return dao.getOPDPatients(username);
	}

	public OPDPatient getOPDPatientProfile(Integer patientID) {
		dao=new HMSDaoImpl();
		return dao.getOPDPatientProfile(patientID);
	}

	public boolean updateOPDPatient(OPDPatient patient) {
		dao=new HMSDaoImpl();
		return dao.updateOPDPatient(patient);
	}

	public int getNewIPDPatientID() {
		dao=new HMSDaoImpl();
		return dao.getNewIPDPatientID();
	}

	public boolean addIPDPatient(IPDPatient patient) {
		dao=new HMSDaoImpl();
		return dao.addIPDPatient(patient);
	}

	public List<IPDPatient> getIPDPatients() {
		dao=new HMSDaoImpl();
		return dao.getIPDPatients();
	}

	public List<IPDPatient> getIPDPatients(String username) {
		dao=new HMSDaoImpl();
		return dao.getIPDPatients(username);
	}

	public IPDPatient getIPDPatientProfile(Integer patientID) {
		dao=new HMSDaoImpl();
		return dao.getIPDPatientProfile(patientID);
	}

	public boolean updateIPDPatient(IPDPatient patient) {
		dao=new HMSDaoImpl();
		return dao.updateIPDPatient(patient);
	}

	public boolean deletePatient(Patient patient) {
		dao=new HMSDaoImpl();
		return dao.deletePatient(patient);
	}

	public List<IPDPatient> getBeds(int roomID) {
		dao=new HMSDaoImpl();
		return dao.getBeds(roomID);
	}


	
		
}
