package com.hms.domain;

public class Room {

	private int roomID;
	private int roomNo;
	private int roomRate;
	private int totalBeds;
	private int occupiedBeds;
	private int unoccupiedBeds;
	private Floor floor;
	private RoomCategory category;
	public int getRoomID() {
		return roomID;
	}
	public void setRoomID(int roomID) {
		this.roomID = roomID;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public int getRoomRate() {
		return roomRate;
	}
	public void setRoomRate(int roomRate) {
		this.roomRate = roomRate;
	}
	public Floor getFloor() {
		return floor;
	}
	public void setFloor(Floor floor) {
		this.floor = floor;
	}
	public RoomCategory getCategory() {
		return category;
	}
	public void setCategory(RoomCategory category) {
		this.category = category;
	}
	public int getTotalBeds() {
		return totalBeds;
	}
	public void setTotalBeds(int totalBeds) {
		this.totalBeds = totalBeds;
	}
	public int getOccupiedBeds() {
		return occupiedBeds;
	}
	public void setOccupiedBeds(int occupiedBeds) {
		this.occupiedBeds = occupiedBeds;
	}
	public int getUnoccupiedBeds() {
		return unoccupiedBeds;
	}
	public void setUnoccupiedBeds(int unoccupiedBeds) {
		this.unoccupiedBeds = unoccupiedBeds;
	}
	
	
	
}
