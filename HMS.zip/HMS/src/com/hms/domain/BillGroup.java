package com.hms.domain;

public class BillGroup {
	
	private int billGroupID;
	private String billGroupName;
	private String billGroupDescription;
	public int getBillGroupID() {
		return billGroupID;
	}
	public void setBillGroupID(int billGroupID) {
		this.billGroupID = billGroupID;
	}
	public String getBillGroupName() {
		return billGroupName;
	}
	public void setBillGroupName(String billGroupName) {
		this.billGroupName = billGroupName;
	}
	public String getBillGroupDescription() {
		return billGroupDescription;
	}
	public void setBillGroupDescription(String billGroupDescription) {
		this.billGroupDescription = billGroupDescription;
	}
	
	

}
