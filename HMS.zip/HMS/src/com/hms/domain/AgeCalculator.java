package com.hms.domain;

import java.sql.Date;


public class AgeCalculator {
	
	public int calculateAge(Date birthDate)
	{
		System.out.println("inside age calculator");
		System.out.println(birthDate);
		java.util.Date currentdate=new java.util.Date();
		System.out.println(currentdate);
	    java.sql.Date sqlDate = birthDate;
	    java.util.Date utilDate = new java.util.Date(sqlDate.getTime());
	    System.out.println(utilDate);
	    System.out.println(currentdate.getTime());
	    System.out.println(utilDate.getTime());
	    long ageInMillis = currentdate.getTime() - utilDate.getTime();
	    System.out.println(ageInMillis);
	    ageInMillis=(ageInMillis)/(365*24*36);
	    double result=ageInMillis/100000;
	    System.out.println(result);
	    return (int)result;
	  
	}


}