package com.hms.domain;

public class Designation {
	
	private int designationID;
	private String designationName;
	private String designationDescription;
	public int getDesignationID() {
		return designationID;
	}
	public void setDesignationID(int designationID) {
		this.designationID = designationID;
	}
	public String getDesignationName() {
		return designationName;
	}
	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}
	public String getDesignationDescription() {
		return designationDescription;
	}
	public void setDesignationDescription(String designationDescription) {
		this.designationDescription = designationDescription;
	}
	
	

}
