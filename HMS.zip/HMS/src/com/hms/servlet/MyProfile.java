package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.LoginUser;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class MyProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private IHMSService service;
    
    public MyProfile() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 HttpSession session=request.getSession(false);  
		 
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        String userid=request.getParameter("userid");
	        service=new HMSServiceImpl();
	        LoginUser user;
	        if(userid!=null)
	        {
	        	user=service.getProfile(Integer.parseInt(userid));
	        }
	        else
	        user=service.getProfile(username);
	        
	        RequestDispatcher rd=request.getRequestDispatcher("jsp/MyProfile.jsp");
	        request.setAttribute("userProfile",user);
			rd.forward(request,response);
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
