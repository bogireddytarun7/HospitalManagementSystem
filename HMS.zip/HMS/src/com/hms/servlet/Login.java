package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class Login extends HttpServlet{
	
	private static final long serialVersionUID = 1L;
	private IHMSService service;
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{	
		System.out.println("helo hello hello");
		String username=request.getParameter("username");
		System.out.println(username);
		String password=request.getParameter("password");
		System.out.println(password);
		 HttpSession session=request.getSession();  
		 if (session.isNew()) {
			    // Not created yet. Now do so yourself.
			    session = request.getSession();
			    session.setAttribute("username",username);
			    
			} else {
				System.out.println("credentials verified");
				RequestDispatcher rd=request.getRequestDispatcher("./HTML/MainPage.html");
				rd.forward(request,response);
			}
	          
		 
		service=new HMSServiceImpl();
		if(service.verify(username, password))
		{
			System.out.println("credentials verified");
			RequestDispatcher rd=request.getRequestDispatcher("./HTML/MainPage.html");
			rd.forward(request,response);
		}
		else
		{
			
	    	   RequestDispatcher rd=request.getRequestDispatcher("./HTML/LoginFailure.html");
	    	   rd.forward(request,response);
		}
	}
}
