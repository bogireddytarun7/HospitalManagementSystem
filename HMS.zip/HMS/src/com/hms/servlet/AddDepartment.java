package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

/**
 * Servlet implementation class AddDepartment
 */
public class AddDepartment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IHMSService service;
	
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String departmentName=request.getParameter("dname");
		System.out.println("Department Name="+departmentName);
		service=new HMSServiceImpl();
		if(service.addDepartment(departmentName))
	      {
	    	  	System.out.println("new department is inserted");
	    	  	request.setAttribute("message", "Department added successfully!");
		        RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
				rd.forward(request,response);
	      }
		
		
	}

	
}
