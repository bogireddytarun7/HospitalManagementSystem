package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.BillGroup;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class AddBillGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String billgroupname=request.getParameter("bgname");
		System.out.println("bill group Name="+billgroupname);
		String billgroupdescription=request.getParameter("bgdesc");
		BillGroup billgroup=new BillGroup();
		billgroup.setBillGroupName(billgroupname);
		billgroup.setBillGroupDescription(billgroupdescription);
		service=new HMSServiceImpl();
		if(service.addBillGroup(billgroup))
	      {
	    	  	System.out.println("new bill group is inserted");
	    	  	request.setAttribute("message", "Bill Group Name added successfully!");
		        RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
				rd.forward(request,response);
	      }
		
		
	}

}
