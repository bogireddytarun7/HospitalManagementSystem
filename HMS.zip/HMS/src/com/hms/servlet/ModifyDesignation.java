package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.Designation;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class ModifyDesignation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int designation_id=Integer.parseInt(request.getParameter("did"));
		String designation_name=request.getParameter("dname");
		String designation_description=request.getParameter("ddesc");
		Designation designation=new Designation();
		designation.setDesignationID(designation_id);
		designation.setDesignationName(designation_name);
		designation.setDesignationDescription(designation_description);
		service=new HMSServiceImpl();
		if(service.modifyDesignation(designation))
		{
	    	   System.out.println("updated designation");
	    	   request.setAttribute("message", "Designation updated successfully!");
	    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
	    	   rd.forward(request,response);
		}
		
	}


	
}
