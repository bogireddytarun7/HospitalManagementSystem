package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.Designation;
import com.hms.domain.RoomCategory;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class ModifyRoomCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int categoryId=Integer.parseInt(request.getParameter("cid"));
		String categoryName=request.getParameter("cname");
		String description=request.getParameter("cdesc");
		RoomCategory category=new RoomCategory();
		category.setCategoryId(categoryId);
		category.setCategoryName(categoryName);
		category.setDescription(description);
	
		service=new HMSServiceImpl();
		if(service.modifyRoomCategory(category))
		{
	    	   System.out.println("updated room category");
	    	   request.setAttribute("message", "Room Category updated successfully!");
	    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
	    	   rd.forward(request,response);
		}
		
	}


}
