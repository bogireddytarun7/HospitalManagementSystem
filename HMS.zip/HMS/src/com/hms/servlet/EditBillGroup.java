package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.BillGroup;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class EditBillGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer billgroup_id=Integer.parseInt(request.getParameter("bgid"));
		service=new HMSServiceImpl();
		BillGroup billgroup=new BillGroup();
		billgroup.setBillGroupID(billgroup_id);
		billgroup=service.getBillGroup(billgroup);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/ModifyBillGroup.jsp");
        request.setAttribute("billgroup",billgroup);
		rd.forward(request,response);
	}

	

}
