package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class CheckUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{	
		
		String username=request.getParameter("username");
		int userid=Integer.parseInt(request.getParameter("userid"));
		System.out.println(username);
		 
		service=new HMSServiceImpl();
		if(!service.checkUser(username,userid))
		{
			RequestDispatcher rd=request.getRequestDispatcher("jsp/CreateCredentials.jsp");
			request.setAttribute("username", username);
			request.setAttribute("userid", userid);
			rd.forward(request,response);
		}
	}
	
}
