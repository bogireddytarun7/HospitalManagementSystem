package com.hms.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.Designation;
import com.hms.domain.Room;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class RoomMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);  
		 
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        service=new HMSServiceImpl();
	        List<Room> rooms=service.getRooms();
	        Iterator<Room> itr=rooms.listIterator();
            
            while(itr.hasNext())
            {
            	Room room=itr.next();
            	System.out.println(room.getRoomID()+"\t"+room.getRoomNo()+"\t"+room.getRoomRate()+"\t"+room.getTotalBeds()+"\t"+room.getFloor().getFloorName()+"\t"+room.getCategory().getCategoryName());
            }
	        RequestDispatcher rd=request.getRequestDispatcher("jsp/RoomMaster.jsp");
	        request.setAttribute("rooms",rooms);
			rd.forward(request,response);
	}

}
