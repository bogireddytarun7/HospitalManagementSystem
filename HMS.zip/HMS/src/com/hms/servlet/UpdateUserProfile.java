package com.hms.servlet;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.LoginUser;
import com.hms.domain.UserCredentials;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class UpdateUserProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private IHMSService service;
    
    public UpdateUserProfile() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 HttpSession session=request.getSession(false);  
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        LoginUser user=new LoginUser();
	        
	        String lname=request.getParameter("lname");
	        System.out.println(lname);
	        user.setLastName(lname);
	        String fname=request.getParameter("fname");
	        System.out.println(fname);
	        user.setFirstName(fname);
	        String mname=request.getParameter("mname");
	        System.out.println(mname);
	        user.setMiddleName(mname);
	        System.out.println(request.getParameter("dob"));
	        DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	        try{
	        java.util.Date date = formatter.parse(request.getParameter("dob"));
	        java.sql.Date birthdate = new java.sql.Date(date.getTime()); 
	        user.setBirthdate(birthdate);
	        System.out.println("sql date converted "+birthdate);
	        }catch(ParseException pe)
	        {
	        	
	        }
	        
	        Long phone=Long.parseLong(request.getParameter("phone"));
	        System.out.println(phone);
	        user.setPhone(phone);
	        String email=request.getParameter("email");
	        System.out.println(email);
	        user.setEmail(email);
	        
	        String birthplace=request.getParameter("birthplace");
	        System.out.println(birthplace);
	        user.setBirthPlace(birthplace);
	        String gender=request.getParameter("gender");
	        System.out.println(gender);
	        user.setGender(gender);
	        String status=request.getParameter("status");
	        System.out.println(status);
	        user.setCivilStatus(status);
	        UserCredentials credentials=new UserCredentials();
	        credentials.setUsername(username);
	        user.setUserCredentials(credentials);
	        service=new HMSServiceImpl();
	       if(service.updateProfile(user))
	       {
	    	   System.out.println("updated user profile");
	        RequestDispatcher rd=request.getRequestDispatcher("/MyProfile");
			rd.forward(request,response);
	       }
			
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
