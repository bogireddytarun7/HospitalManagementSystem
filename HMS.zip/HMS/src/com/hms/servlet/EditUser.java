package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.LoginUser;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class EditUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IHMSService service;
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		System.out.println("userid="+userid);
		service=new HMSServiceImpl();
		LoginUser user=service.getProfile(userid);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/EditUser.jsp");
        request.setAttribute("userProfile",user);
		rd.forward(request,response);
	}


}
