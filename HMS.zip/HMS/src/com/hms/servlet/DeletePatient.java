package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.LoginUser;
import com.hms.domain.Patient;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class DeletePatient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int patientID=Integer.parseInt(request.getParameter("patientID"));
		Patient patient=new Patient();
		patient.setPatientID(patientID);
		
		service=new HMSServiceImpl();
		if(service.deletePatient(patient))
		{
	    	   System.out.println("deleted Patient");
	    	   request.setAttribute("message", "Patient deleted successfully!");
	    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
	    	   rd.forward(request,response);
		}

	}

	
}
