package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.Designation;
import com.hms.domain.RoomCategory;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class EditRoomCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Integer categoryId=Integer.parseInt(request.getParameter("cid"));
		service=new HMSServiceImpl();
		RoomCategory category=new RoomCategory();
		category.setCategoryId(categoryId);
		RoomCategory category1=service.getRoomCategory(category);
		
		RequestDispatcher rd=request.getRequestDispatcher("jsp/ModifyRoomCategory.jsp");
        request.setAttribute("category",category1);
		rd.forward(request,response);
	}



}
