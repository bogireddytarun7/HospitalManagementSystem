package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.LoginUser;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class DeleteUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userid=Integer.parseInt(request.getParameter("userid"));
		LoginUser user=new LoginUser();
		user.setUserID(userid);
		service=new HMSServiceImpl();
		if(service.deleteUser(user))
		{
	    	   System.out.println("deleted User");
	    	   request.setAttribute("message", "User deleted successfully!");
	    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
	    	   rd.forward(request,response);
		}

	}
}
