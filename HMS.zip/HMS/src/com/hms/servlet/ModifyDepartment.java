package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.Department;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class ModifyDepartment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int department_id=Integer.parseInt(request.getParameter("deptid"));
		String department_name=request.getParameter("deptname");
		Department department = new Department();
		department.setDepartmentID(department_id);
		department.setDepartmentName(department_name);
		service=new HMSServiceImpl();
		if(service.modifyDepartment(department))
		{
	    	   System.out.println("updated department");
	    	   request.setAttribute("message", "Department updated successfully!");
	    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
	    	   rd.forward(request,response);
		}
		
		
	}

	

}
