package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.LoginUser;
import com.hms.domain.Patient;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class EditPatientProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int patientID=Integer.parseInt(request.getParameter("patientID"));
		System.out.println("patientid="+patientID);
		service=new HMSServiceImpl();
		Patient patient=service.getPatientProfile(patientID);
		RequestDispatcher rd=request.getRequestDispatcher("jsp/EditPatientProfile.jsp");
        request.setAttribute("patient",patient);
		rd.forward(request,response);
	}

	
}
