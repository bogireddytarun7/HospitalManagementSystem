package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.LoginUser;
import com.hms.domain.UserCredentials;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class CreateCredentials extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int userid=Integer.parseInt(request.getParameter("userid"));
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		LoginUser user=new LoginUser();
		user.setUserID(userid);
		UserCredentials credentials=new UserCredentials();
		credentials.setUsername(username);
		credentials.setPassword(password);
		user.setUserCredentials(credentials);
		
		service=new HMSServiceImpl();
		if(service.createCredentials(user))
	      {
	    	  	System.out.println("new user credentials inserted");
	    	  	request.setAttribute("message", "User Credentials added successfully!");
		        RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
				rd.forward(request,response);
	      }
		
		
	}

}
