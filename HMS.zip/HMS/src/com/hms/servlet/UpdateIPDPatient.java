package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.IPDPatient;
import com.hms.domain.OPDPatient;
import com.hms.domain.PatientHistory;
import com.hms.domain.VitalParameters;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;
import com.hms.util.NumberCheck;


public class UpdateIPDPatient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);  
		 
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        IPDPatient patient=new IPDPatient();
	        
	        Integer patientID=Integer.parseInt(request.getParameter("pid"));
	        patient.setPatientID(patientID);
	        
	        Integer patientIPDID=Integer.parseInt(request.getParameter("ipdpid"));
	        patient.setPatientIPDID(patientIPDID);
	        
	        patient.setDiagnosis(request.getParameter("diagnosis"));
	        patient.setMedication(request.getParameter("medication"));
	        patient.setComplain(request.getParameter("complain"));
	        
	        VitalParameters parameters=new VitalParameters();
	        NumberCheck check=new NumberCheck();
	        String bp=request.getParameter("bp");
	        System.out.println(bp);
	        if(check.isNumeric(bp))
	        parameters.setBp(Integer.parseInt(bp));
	        else
	        parameters.setBp(0);
	        
	        String pulseRate=request.getParameter("pulserate");
	        if(check.isNumeric(pulseRate))
	        parameters.setPulseRate(Integer.parseInt(pulseRate));
	        else
	        parameters.setPulseRate(0);
	        
	        
	        String temperature=request.getParameter("temperature");
	        System.out.println(temperature);
	        if(check.isNumeric(temperature))
	        parameters.setTemperature(Double.parseDouble(temperature));
	        else
	        parameters.setTemperature(0);
	        
	        String respiration=request.getParameter("respiration");
	        if(check.isNumeric(respiration))
	        parameters.setRespiration(Integer.parseInt(respiration));
	        else
	        parameters.setRespiration(0);
	        
	        String height=request.getParameter("height");
	        if(check.isNumeric(height))
	        parameters.setHeight(Double.parseDouble(height));
	        else
	        parameters.setHeight(0);
	        
	        String weight=request.getParameter("weight");
	        if(check.isNumeric(weight))
	        parameters.setWeight(Double.parseDouble(weight));
	        else
	        parameters.setWeight(0);
	        
	        patient.setVitalParameters(parameters);
	        
	        PatientHistory history=new PatientHistory();
	        
	        history.setAllergies(request.getParameter("allergies"));
	        history.setFamilyHistory(request.getParameter("familyhistory"));
	        history.setPastMedicalHistory(request.getParameter("pastmedicalhistory"));
	        history.setPersonalHistory(request.getParameter("personalhistory"));
	        history.setSocialHistory(request.getParameter("socialhistory"));
	        history.setWarnings(request.getParameter("warnings"));
	        
	        patient.setPatientHistory(history);
	        
	        
	        service=new HMSServiceImpl();
	        if(service.updateIPDPatient(patient))
	        {
		    	   System.out.println("updated ipd patient information");
		    	   request.setAttribute("message", "IPD Patient information updated successfully!");
		    	   RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
		    	   rd.forward(request,response);
			}
	}


	

}
