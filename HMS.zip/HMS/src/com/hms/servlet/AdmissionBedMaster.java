package com.hms.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.Bed;
import com.hms.domain.IPDPatient;
import com.hms.domain.Room;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;


public class AdmissionBedMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);  
		 
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        
	        int roomID=Integer.parseInt(request.getParameter("roomID"));
	        
	        
	        service=new HMSServiceImpl();
	        List<IPDPatient> patients=service.getBeds(roomID);
	        Iterator<IPDPatient> itr=patients.listIterator();
	        while(itr.hasNext())
	        {
	        	IPDPatient patient=itr.next();
	        	System.out.println(patient.isBedStatus()+"\t"+patient.getBed().getBedNo());
	        }
            
            
	        RequestDispatcher rd=request.getRequestDispatcher("jsp/AdmissionBedMaster.jsp");
	        request.setAttribute("patients",patients);
			rd.forward(request,response);
	}

	
}
