package com.hms.servlet;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hms.domain.Bed;
import com.hms.domain.Room;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class RoomBedMaster extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	private IHMSService service;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);  
		 
		 System.out.println("session value "+(String)session.getAttribute("username"));
	        String username=(String)session.getAttribute("username"); 
	        service=new HMSServiceImpl();
	        List<Bed> beds=service.getBeds();
	        Iterator<Bed> itr=beds.listIterator();
            
            while(itr.hasNext())
            {
            	Bed bed=itr.next();
            	Room room=bed.getRoom();
            	System.out.println(bed.getBedNo()+"\t"+room.getRoomID()+"\t"+room.getRoomNo()+"\t"+room.getRoomRate()+"\t"+room.getTotalBeds()+"\t"+room.getFloor().getFloorName()+"\t"+room.getCategory().getCategoryName());
            }
	        RequestDispatcher rd=request.getRequestDispatcher("jsp/RoomBedMaster.jsp");
	        request.setAttribute("beds",beds);
			rd.forward(request,response);
	}

	
}
