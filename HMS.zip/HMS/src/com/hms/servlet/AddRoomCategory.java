package com.hms.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hms.domain.Designation;
import com.hms.domain.RoomCategory;
import com.hms.service.HMSServiceImpl;
import com.hms.service.IHMSService;

public class AddRoomCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
   
	private IHMSService service;
	
	   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String roomCategoryName=request.getParameter("cname");
		String categoryDescription=request.getParameter("cdesc");
		RoomCategory category=new RoomCategory();
		category.setCategoryName(roomCategoryName);
		category.setDescription(categoryDescription);
		service=new HMSServiceImpl();
		if(service.addRoomCategory(category))
	      {
	    	  	System.out.println("new room category is inserted");
	    	  	request.setAttribute("message", "Room Category added successfully!");
		        RequestDispatcher rd=request.getRequestDispatcher("jsp/success.jsp");
				rd.forward(request,response);
	      }
		
		
	}
	

}
